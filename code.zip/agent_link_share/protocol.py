"""
High-level chatbot-to-chatbot interface for sharing service links.

An AgentNode is one chatbot's endpoint. It composes three separately
verifiable checks on receipt -- signature validity, TOFU key-pin
consistency, replay/expiry -- before ever looking at payload content, and
only after all three pass does it apply any policy about whether to accept,
register, or re-propagate what it received.

This ordering matters: policy decisions (should I trust this, should I
pass it on) must never run on unauthenticated data. Verify identity and
freshness FIRST, unconditionally; decide what to do with the content SECOND.

IMPORTANT for callers writing policy_should_accept: it runs BEFORE the
registry is updated with the new claim, so a policy that wants to check
"does this match what I previously knew about this service_url" can safely
read self.registry[link.service_url] and get the PRIOR entry, not the
one currently being considered. See demo.py's manifest-continuity policy.
"""

import time
from dataclasses import dataclass, field

from wire_format import (
    Envelope, build_and_sign_envelope, verify_envelope_signature, check_freshness,
    SignatureInvalid, EnvelopeExpired, ReplayDetected,
)
from identity import AgentIdentity, TOFUStore, ReplayGuard, KeyPinningViolation
from service_link import ServiceLinkPayload, KnownService, find_adjacent_services

MSG_TYPE_SERVICE_LINK_SHARE = "service_link_share"


@dataclass
class ReceiveResult:
    accepted: bool
    reason: str
    service: KnownService | None = None
    adjacent_suggestions: list[tuple[KnownService, float]] = field(default_factory=list)
    should_propagate: bool = False


class AgentNode:
    def __init__(self, identity: AgentIdentity | None = None,
                 min_scope_required: set[str] | None = None,
                 max_propagation_hops: int = 4):
        self.identity = identity or AgentIdentity.generate()
        self.tofu = TOFUStore()
        self.replay_guard = ReplayGuard()
        self.registry: dict[str, KnownService] = {}     # service_url -> KnownService
        self.min_scope_required = min_scope_required or {"read"}
        self.max_propagation_hops = max_propagation_hops

    # ---- sending ----

    def share_service_link(self, link: ServiceLinkPayload, hop_count: int = 0, ttl_seconds: int = 300) -> Envelope:
        payload = link.to_dict()
        payload["_hop_count"] = hop_count  # travels inside payload so receivers can enforce max hops
        return build_and_sign_envelope(
            msg_type=MSG_TYPE_SERVICE_LINK_SHARE,
            sender_id=self.identity.agent_id,
            sender_pubkey=self.identity.public_key,
            private_key=self.identity.private_key,
            payload=payload,
            ttl_seconds=ttl_seconds,
        )

    # ---- receiving ----

    def receive_envelope(self, env: Envelope, policy_should_accept=None, policy_should_propagate=None) -> ReceiveResult:
        """policy_should_accept(link, env) -> bool: application-level trust
        decision. policy_should_propagate(link, env) -> bool: separate
        decision of whether to re-share what was received. Both are
        injectable callbacks so callers can wire in whatever trust model
        they want without touching the verification pipeline below.
        """
        # 1. Signature -- unconditional, first, no exceptions.
        try:
            verify_envelope_signature(env)
        except SignatureInvalid as e:
            return ReceiveResult(accepted=False, reason=f"signature_invalid: {e}")

        # 2. Freshness -- reject stale envelopes before any further processing.
        try:
            check_freshness(env)
        except EnvelopeExpired as e:
            return ReceiveResult(accepted=False, reason=f"expired: {e}")

        # 3. TOFU pin check -- catches a claimed-id/key mismatch for a
        #    previously-known agent (see identity.py docstring for exactly
        #    what this does and doesn't catch, given id is key-derived).
        try:
            self.tofu.check_and_pin(env.sender_id, env.sender_pubkey_b64)
        except KeyPinningViolation as e:
            return ReceiveResult(accepted=False, reason=f"tofu_violation: {e}")

        # 4. Replay check -- after TOFU/signature so a replayed envelope
        #    from an impersonator doesn't even reach this check.
        try:
            self.replay_guard.check_and_record(env.sender_id, env.nonce)
        except ReplayDetected as e:
            return ReceiveResult(accepted=False, reason=f"replay: {e}")

        if env.msg_type != MSG_TYPE_SERVICE_LINK_SHARE:
            return ReceiveResult(accepted=False, reason=f"unhandled msg_type: {env.msg_type}")

        # ---- only now do we look at content ----
        link = ServiceLinkPayload.from_dict(env.payload)
        hop_count = env.payload.get("_hop_count", 0)

        if hop_count > self.max_propagation_hops:
            return ReceiveResult(accepted=False, reason=f"hop_count {hop_count} exceeds max {self.max_propagation_hops}")

        if policy_should_accept is not None and not policy_should_accept(link, env):
            return ReceiveResult(accepted=False, reason="rejected_by_policy")

        svc = KnownService(
            service_url=link.service_url,
            capability_tags=set(link.capability_tags),
            scope=set(link.scope),
            manifest_hash=link.manifest_hash,
            learned_from=env.sender_id,
            first_seen=time.time(),
        )
        adjacent = find_adjacent_services(svc, self.registry)
        self.registry[svc.service_url] = svc

        should_propagate = False
        if policy_should_propagate is not None:
            should_propagate = policy_should_propagate(link, env)

        return ReceiveResult(
            accepted=True, reason="ok", service=svc,
            adjacent_suggestions=adjacent, should_propagate=should_propagate,
        )

    def re_share(self, original_env: Envelope, ttl_seconds: int = 300) -> Envelope:
        """Re-signs as THIS agent forwarding, with incremented hop count --
        never forwards the original envelope's signature (that would let a
        forwarder impersonate the original sender). Provenance of "who told
        me this" is preserved via trust_hint.endorsed_by, not by reusing
        someone else's signature."""
        link = ServiceLinkPayload.from_dict(original_env.payload)
        hop_count = original_env.payload.get("_hop_count", 0) + 1
        trust_hint = dict(link.trust_hint)
        endorsed_by = list(trust_hint.get("endorsed_by", []))
        endorsed_by.append(original_env.sender_id)
        trust_hint["endorsed_by"] = endorsed_by
        forwarded = ServiceLinkPayload(
            service_url=link.service_url, capability_tags=link.capability_tags,
            scope=link.scope, manifest_hash=link.manifest_hash,
            trust_hint=trust_hint, description=link.description,
        )
        return self.share_service_link(forwarded, hop_count=hop_count, ttl_seconds=ttl_seconds)
