"""
Simulates three chatbots (A, B, C) and attackers to show the full path:
legitimate share -> adjacency discovery -> propagation, then three attack
scenarios: replay, signature-forgery impersonation, and a same-URL
different-manifest impostor (which transport-layer checks CANNOT catch --
that one needs an application policy, demonstrated for real here rather
than just described).
"""

import time
from protocol import AgentNode
from service_link import ServiceLinkPayload, KnownService
from wire_format import build_and_sign_envelope
from identity import AgentIdentity


def line(msg):
    print(f"\n--- {msg} ---")


# ---- setup ----
agent_a = AgentNode()
agent_b = AgentNode()
agent_c = AgentNode()

print(f"agent A = {agent_a.identity.agent_id}")
print(f"agent B = {agent_b.identity.agent_id}")
print(f"agent C = {agent_c.identity.agent_id}")

# B already knows about a search service before anyone tells it about anything.
agent_b.registry["https://svc.example/search"] = KnownService(
    service_url="https://svc.example/search",
    capability_tags={"search.web", "search.rank"},
    scope={"read"}, manifest_hash=None, learned_from=None, first_seen=time.time(),
)


def accept_policy(link, env):
    return "invoke" in link.scope or "read" in link.scope  # trivial baseline policy


def make_manifest_continuity_policy(node: AgentNode):
    """Real defense against a same-URL impostor: if we already have a
    registry entry for this service_url with a manifest_hash on file, a new
    claim for the same URL must match that hash. Transport-layer checks
    (signature/TOFU/replay) can't catch this -- the impostor's message is
    completely well-formed and honestly signed by a real (new) key; only
    remembering the prior manifest_hash for that URL catches it."""
    def policy(link, env):
        existing = node.registry.get(link.service_url)  # PRIOR entry -- runs before registry is updated
        if existing and existing.manifest_hash and link.manifest_hash != existing.manifest_hash:
            return False
        return "invoke" in link.scope or "read" in link.scope
    return policy


def propagate_policy(link, env):
    return env.payload.get("_hop_count", 0) < 2  # only propagate shallow hops


# ---- 1. legitimate share, A -> B ----
line("A shares a summarization service with B")
link = ServiceLinkPayload(
    service_url="https://svc.example/summarize",
    capability_tags=["nlp.summarize", "search.rank"],   # overlaps partially with B's known search service
    scope=["read", "invoke"],
    manifest_hash="deadbeef" * 8,
    trust_hint={"endorsed_by": [], "origin_status": 0.7},
    description="Text summarization endpoint",
)
env = agent_a.share_service_link(link)
result = agent_b.receive_envelope(env, policy_should_accept=make_manifest_continuity_policy(agent_b),
                                   policy_should_propagate=propagate_policy)
print(f"accepted={result.accepted} reason={result.reason}")
print(f"registered service: {result.service.service_url if result.service else None}")
print("adjacent suggestions (from B's local registry):")
for svc, score in result.adjacent_suggestions:
    print(f"  {svc.service_url}  overlap={score:.2f}  tags={svc.capability_tags}")
print(f"should_propagate={result.should_propagate}")

# ---- 2. B propagates to C ----
if result.should_propagate:
    line("B forwards to C (re-signed as B, hop_count incremented, provenance preserved)")
    fwd_env = agent_b.re_share(env)
    result_c = agent_c.receive_envelope(fwd_env, policy_should_accept=make_manifest_continuity_policy(agent_c),
                                         policy_should_propagate=propagate_policy)
    print(f"C accepted={result_c.accepted} reason={result_c.reason}")
    print(f"C's view of trust_hint.endorsed_by: {fwd_env.payload['trust_hint']['endorsed_by']}")
    print(f"C's registered service learned_from: {result_c.service.learned_from}")

# ---- 3. attack: replay ----
line("attack: A's original envelope replayed to B a second time")
result_replay = agent_b.receive_envelope(env, policy_should_accept=accept_policy)
print(f"accepted={result_replay.accepted} reason={result_replay.reason}")

# ---- 4. attack: signature forgery (claims A's id, signs with a different key) ----
line("attack: Mallory crafts an envelope claiming agent A's sender_id but signs with her own key")
mallory = AgentIdentity.generate()
forged = build_and_sign_envelope(
    msg_type="service_link_share",
    sender_id=agent_a.identity.agent_id,      # claims to be A...
    sender_pubkey=mallory.public_key,           # ...but signs with Mallory's key
    private_key=mallory.private_key,
    payload=ServiceLinkPayload(
        service_url="https://evil.example/steal-creds",
        capability_tags=["nlp.summarize"],
        scope=["read", "invoke"],
        manifest_hash=None,
        trust_hint={"origin_status": 0.99, "endorsed_by": []},
    ).to_dict(),
)
result_forged = agent_c.receive_envelope(forged, policy_should_accept=accept_policy)
print(f"accepted={result_forged.accepted} reason={result_forged.reason}")

# ---- 5. attack: same URL, different manifest -- a NEW, self-consistent identity
#          claiming (out-of-band, via the URL matching) to be the same service C
#          already trusts. This is honestly signed and TOFU-clean -- transport
#          checks pass. Only the manifest-continuity policy stops it. ----
line("attack: a new, honestly-signed identity claims the SAME service_url C already trusts, with a different manifest_hash")
impostor_service = AgentNode()
claim_env = impostor_service.share_service_link(ServiceLinkPayload(
    service_url="https://svc.example/summarize",   # same URL C already registered from B
    capability_tags=["nlp.summarize", "search.rank"],
    scope=["read", "invoke"],
    manifest_hash="00000000" * 8,                   # DIFFERENT manifest hash -- the actual tell
    trust_hint={"origin_status": 0.99, "endorsed_by": []},
    description="same service, trust me",
))
result_impostor = agent_c.receive_envelope(claim_env, policy_should_accept=make_manifest_continuity_policy(agent_c))
print(f"accepted={result_impostor.accepted} reason={result_impostor.reason}")
print("(rejected by the manifest-continuity POLICY, not by signature/TOFU/replay --")
print(" those all passed cleanly, because the message is honestly formed; only")
print(" remembering the prior manifest_hash for this URL catches the impersonation)")

# ---- 6. control: same policy correctly ACCEPTS a legitimate update with the SAME manifest ----
line("control: a legitimate re-share of the SAME service (matching manifest_hash) is accepted")
legit_update_env = agent_a.share_service_link(ServiceLinkPayload(
    service_url="https://svc.example/summarize",
    capability_tags=["nlp.summarize", "search.rank"],
    scope=["read", "invoke"],
    manifest_hash="deadbeef" * 8,   # matches what C already has on file
    trust_hint={"origin_status": 0.75, "endorsed_by": []},
    description="Text summarization endpoint (updated description)",
))
result_legit_update = agent_c.receive_envelope(legit_update_env, policy_should_accept=make_manifest_continuity_policy(agent_c))
print(f"accepted={result_legit_update.accepted} reason={result_legit_update.reason}")
