# Chatbot-to-chatbot service-link sharing protocol

A signed, TOFU-pinned, replay-protected wire format for agents to share
links to services with each other, plus emergent "modularly adjacent"
service discovery based on local capability-tag overlap.

## Files

- `wire_format.py` — **low-level layer**. Canonical JSON encoding, ed25519
  sign/verify, the `Envelope` structure (versioned, nonce'd, TTL'd). Knows
  nothing about "service links" — pure transport primitive.
- `identity.py` — **low-level layer**. `AgentIdentity` (keypair + derived
  address), `TOFUStore` (pin-on-first-contact), `ReplayGuard` (nonce cache
  with GC).
- `service_link.py` — **high-level layer**. `ServiceLinkPayload` schema
  (url, capability tags, scope, manifest hash, trust hint), and
  `find_adjacent_services` — Jaccard tag-overlap adjacency discovery run
  locally by each receiver, not declared by the sender.
- `protocol.py` — **high-level layer**. `AgentNode`: `share_service_link`,
  `receive_envelope` (ordered check pipeline: signature → freshness → TOFU
  → replay → policy), `re_share` (forwards with incremented hop count and
  provenance, never reuses another agent's signature).
- `demo.py` — six scenarios: legitimate share, propagation with adjacency
  discovery, replay rejection, signature-forgery rejection, a same-URL
  different-manifest impostor rejection, and a control showing a
  legitimate same-manifest update still gets accepted.

## Key design decisions

**Verify identity/freshness before ever touching content.**
`receive_envelope` runs signature → expiry → TOFU → replay checks
unconditionally, in that order, before any policy callback sees the
payload. Trust decisions never run on unauthenticated data.

**Two different attacks need two different layers of defense.**
- Claiming someone else's `sender_id` while signing with a different key
  is caught by `wire_format.verify_envelope_signature` itself (agent_id is
  derived from the pubkey, so this is a self-consistency check, not a
  policy decision).
- A *new, honestly-signed* identity claiming to be the *same service*
  (same URL) as one you already trust is NOT catchable at the transport
  layer — the message is completely well-formed. This needs an
  application policy that remembers the prior `manifest_hash` for that
  URL and rejects a mismatch (`demo.py`'s
  `make_manifest_continuity_policy`). This is the practical reason
  `manifest_hash` exists in the payload at all: signatures prove *who
  sent this message*, not *what the claimed service actually is*.

**Forwarding re-signs, never relays.**
`re_share` builds a brand-new envelope signed by the forwarding agent,
with hop count incremented and the original sender appended to
`trust_hint.endorsed_by`. Relaying someone else's raw signature would let
a forwarder impersonate the original sender.

**Adjacency is discovered, not declared.**
`find_adjacent_services` runs against the *receiver's own* registry.
Agent A telling B about service X can surface "you might also want Y" even
though A never mentioned Y — adjacency is a property of B's local
knowledge, not a field A fills in.

## What's stubbed / left for extension

- `min_scope_required` enforcement in `receive_envelope` is a no-op
  placeholder — wire in your actual agentlink scope semantics.
- No key-rotation message type — a legitimate rotation currently looks
  identical to an attack and will be rejected by TOFU. Add an explicit,
  separately-authenticated rotation flow if you need this.
- `tag_overlap_score` is plain Jaccard over string tags — swap for
  embedding-cosine similarity if tags turn out too coarse to capture real
  adjacency (this is where the joint-embedding work from the trend-adoption
  pipeline would plug back in).
- No transport (HTTP/MCP/whatever) is implemented — `Envelope.to_dict()` /
  `from_dict()` give you a JSON-serializable message; wiring it onto an
  actual transport is a separate, smaller task.
