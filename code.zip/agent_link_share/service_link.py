"""
Application-level payload: what actually gets shared between agents.

A ServiceLink is a claim: "here's a service at this URL, tagged with these
capabilities, with this trust context." "Modularly adjacent" services are
NOT explicitly linked by the sender -- adjacency is discovered locally by
each receiving agent via capability-tag overlap against services it already
knows about. This means agent B can surface "you might also want service Y"
even though the agent who told B about service X never mentioned Y and may
not know Y exists. That's the point: adjacency is an emergent property of
the local capability registry, not a field the sender fills in.
"""

from dataclasses import dataclass


@dataclass
class ServiceLinkPayload:
    service_url: str
    capability_tags: list[str]           # e.g. ["nlp.summarize", "search.web", "image.generate"]
    scope: list[str]                     # requested/granted scope: ["read", "invoke"]
    manifest_hash: str | None            # sha256 of the remote skill.md / agent manifest -- the actual
                                          # anchor for "is this the same service I saw before", since
                                          # agent_id/signature only prove WHO sent the message, not
                                          # WHAT the claimed service actually is
    trust_hint: dict                     # {"endorsed_by": [...], "origin_status": float|None} -- advisory only, never trusted blindly
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "service_url": self.service_url,
            "capability_tags": sorted(self.capability_tags),  # sorted for canonical signing
            "scope": sorted(self.scope),
            "manifest_hash": self.manifest_hash,
            "trust_hint": self.trust_hint,
            "description": self.description,
        }

    @staticmethod
    def from_dict(d: dict) -> "ServiceLinkPayload":
        return ServiceLinkPayload(
            service_url=d["service_url"], capability_tags=d["capability_tags"],
            scope=d["scope"], manifest_hash=d.get("manifest_hash"),
            trust_hint=d.get("trust_hint", {}), description=d.get("description", ""),
        )


@dataclass
class KnownService:
    """A service registry entry: either learned from a peer, or a service
    the agent already knew about before any sharing happened."""
    service_url: str
    capability_tags: set[str]
    scope: set[str]
    manifest_hash: str | None
    learned_from: str | None            # sender agent_id, or None if locally known
    first_seen: float


def tag_overlap_score(tags_a: set[str], tags_b: set[str]) -> float:
    """Jaccard similarity over capability tags. Cheap, symmetric, and good
    enough as a first-pass adjacency signal; swap for embedding-cosine
    similarity over tag/description text if tags turn out too coarse."""
    if not tags_a or not tags_b:
        return 0.0
    inter = len(tags_a & tags_b)
    union = len(tags_a | tags_b)
    return inter / union if union else 0.0


def find_adjacent_services(
    new_service: KnownService,
    registry: dict[str, KnownService],
    min_overlap: float = 0.15,
    max_results: int = 5,
    exclude_identical_url: bool = True,
) -> list[tuple[KnownService, float]]:
    """'Modularly adjacent' = shares some but not all capability tags with
    something we already know about, and isn't the same service. Excludes
    exact tag-set matches too (that's a duplicate/competitor, not an
    adjacency worth surfacing)."""
    scored = []
    for url, svc in registry.items():
        if exclude_identical_url and url == new_service.service_url:
            continue
        if svc.capability_tags == new_service.capability_tags:
            continue  # same capability set -- not "adjacent", just a duplicate
        overlap = tag_overlap_score(new_service.capability_tags, svc.capability_tags)
        if overlap >= min_overlap:
            scored.append((svc, overlap))
    scored.sort(key=lambda x: -x[1])
    return scored[:max_results]
