"""
Low-level wire format for agent-to-agent messages.

Design constraints:
- Deterministic canonical byte encoding, so signature verification is
  reproducible across implementations/languages (not just this Python code).
- Every message is signed over its own canonical bytes minus the signature
  field itself -- standard sign-then-attach pattern.
- Envelopes carry their own expiry and nonce so replay protection and
  staleness are enforced at this layer, not left to the application.

This module deliberately knows nothing about "service links" or "trend
sharing" -- it's the generic transport primitive. Application-specific
payload schemas live in higher layers (service_link.py, protocol.py).
"""

import json
import base64
import hashlib
import secrets
import time
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

WIRE_VERSION = 1
DEFAULT_TTL_SECONDS = 300          # envelope validity window
NONCE_BYTES = 16


class WireFormatError(Exception):
    pass


class SignatureInvalid(WireFormatError):
    pass


class EnvelopeExpired(WireFormatError):
    pass


class ReplayDetected(WireFormatError):
    pass


def canonical_bytes(obj: dict) -> bytes:
    """Deterministic encoding: sorted keys, no whitespace, UTF-8. This is the
    exact byte string that gets signed -- any implementation on any platform
    must reproduce this exact serialization to verify signatures correctly."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def fingerprint_pubkey(pubkey: ed25519.Ed25519PublicKey) -> str:
    """Short, stable identifier derived from the public key -- used as the
    agent's address. Not a secret; just a content-addressed handle."""
    raw = pubkey.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    return "agt_" + hashlib.sha256(raw).hexdigest()[:32]


def pubkey_to_b64(pubkey: ed25519.Ed25519PublicKey) -> str:
    raw = pubkey.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    return base64.b64encode(raw).decode("ascii")


def pubkey_from_b64(s: str) -> ed25519.Ed25519PublicKey:
    raw = base64.b64decode(s)
    return ed25519.Ed25519PublicKey.from_public_bytes(raw)


@dataclass
class Envelope:
    """The signed transport unit. `payload` is an opaque dict whose schema is
    defined by higher layers (see service_link.py for the service-link-share
    payload shape)."""
    v: int
    msg_type: str
    sender_id: str
    sender_pubkey_b64: str
    issued_at: float
    expires_at: float
    nonce: str
    payload: dict
    signature_b64: str | None = None

    def signing_dict(self) -> dict:
        """Everything except the signature itself -- this is what gets signed
        and what gets re-derived for verification."""
        return {
            "v": self.v,
            "msg_type": self.msg_type,
            "sender_id": self.sender_id,
            "sender_pubkey_b64": self.sender_pubkey_b64,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "nonce": self.nonce,
            "payload": self.payload,
        }

    def to_dict(self) -> dict:
        d = self.signing_dict()
        d["signature_b64"] = self.signature_b64
        return d

    @staticmethod
    def from_dict(d: dict) -> "Envelope":
        return Envelope(
            v=d["v"], msg_type=d["msg_type"], sender_id=d["sender_id"],
            sender_pubkey_b64=d["sender_pubkey_b64"], issued_at=d["issued_at"],
            expires_at=d["expires_at"], nonce=d["nonce"], payload=d["payload"],
            signature_b64=d.get("signature_b64"),
        )


def build_and_sign_envelope(
    msg_type: str,
    sender_id: str,
    sender_pubkey: ed25519.Ed25519PublicKey,
    private_key: ed25519.Ed25519PrivateKey,
    payload: dict,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
) -> Envelope:
    now = time.time()
    env = Envelope(
        v=WIRE_VERSION,
        msg_type=msg_type,
        sender_id=sender_id,
        sender_pubkey_b64=pubkey_to_b64(sender_pubkey),
        issued_at=now,
        expires_at=now + ttl_seconds,
        nonce=secrets.token_hex(NONCE_BYTES),
        payload=payload,
    )
    sig = private_key.sign(canonical_bytes(env.signing_dict()))
    env.signature_b64 = base64.b64encode(sig).decode("ascii")
    return env


def verify_envelope_signature(env: Envelope) -> None:
    """Raises SignatureInvalid if the signature doesn't check out. Does NOT
    check expiry, replay, or TOFU pinning -- those are separate concerns,
    composed at the protocol layer so each failure mode is distinguishable."""
    if env.signature_b64 is None:
        raise SignatureInvalid("envelope has no signature")
    pubkey = pubkey_from_b64(env.sender_pubkey_b64)
    sig = base64.b64decode(env.signature_b64)
    try:
        pubkey.verify(sig, canonical_bytes(env.signing_dict()))
    except InvalidSignature:
        raise SignatureInvalid(f"signature verification failed for {env.sender_id}")

    # sender_id should be derivable from sender_pubkey_b64 -- catches a
    # forged envelope that reuses a valid signature but claims a different
    # identity than the key it's actually signed with.
    expected_id = fingerprint_pubkey(pubkey)
    if expected_id != env.sender_id:
        raise SignatureInvalid(
            f"sender_id {env.sender_id} does not match fingerprint of provided pubkey ({expected_id})"
        )


def check_freshness(env: Envelope, now: float | None = None) -> None:
    now = now if now is not None else time.time()
    if now > env.expires_at:
        raise EnvelopeExpired(f"envelope from {env.sender_id} expired at {env.expires_at}, now {now}")
