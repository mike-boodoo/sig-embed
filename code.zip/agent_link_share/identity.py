"""
Identity + trust-on-first-use pinning + replay protection.

TOFU model: the first time we hear from agent_id X, we pin X's public key.
Any FUTURE message claiming to be from X must verify against that exact
pinned key -- if X's claimed key ever changes, that's treated as a hostile
key-rotation / impersonation attempt, not a routine update, and rejected.
(A legitimate key rotation needs an explicit, separately-authenticated
rotation message -- not implemented here.)

Note on scope: because agent_id is derived deterministically from the
public key (see wire_format.fingerprint_pubkey), an attacker literally
cannot present "agent X's id with a different key" without failing the
signature self-consistency check in wire_format.verify_envelope_signature
first -- that attack is caught one layer earlier. TOFU pinning here is kept
as defense in depth (it also protects the shape of the check if the id
scheme is ever changed to something not derived from the key), but the
attack it uniquely stops is a NEW self-consistent identity impersonating a
previously-known SERVICE (not agent id) -- see service_link.py's
manifest_hash field and demo.py's "manifest continuity" scenario for why
that's a different, application-layer problem.
"""

import time
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric import ed25519

from wire_format import fingerprint_pubkey, WireFormatError


class KeyPinningViolation(WireFormatError):
    pass


@dataclass
class AgentIdentity:
    """A single agent's own keypair + derived address."""
    private_key: ed25519.Ed25519PrivateKey
    public_key: ed25519.Ed25519PublicKey
    agent_id: str

    @staticmethod
    def generate() -> "AgentIdentity":
        priv = ed25519.Ed25519PrivateKey.generate()
        pub = priv.public_key()
        return AgentIdentity(private_key=priv, public_key=pub, agent_id=fingerprint_pubkey(pub))


class TOFUStore:
    """Pinned-key store, one entry per remote agent_id ever contacted."""
    def __init__(self):
        self._pins: dict[str, str] = {}   # agent_id -> pubkey_b64
        self._first_seen: dict[str, float] = {}

    def check_and_pin(self, agent_id: str, pubkey_b64: str, now: float | None = None) -> None:
        now = now if now is not None else time.time()
        if agent_id not in self._pins:
            self._pins[agent_id] = pubkey_b64
            self._first_seen[agent_id] = now
            return
        if self._pins[agent_id] != pubkey_b64:
            raise KeyPinningViolation(
                f"agent {agent_id} presented a different key than the one pinned on first contact "
                f"(first seen at {self._first_seen[agent_id]}) -- possible impersonation or key compromise"
            )

    def is_known(self, agent_id: str) -> bool:
        return agent_id in self._pins

    def pinned_key(self, agent_id: str) -> str | None:
        return self._pins.get(agent_id)


class ReplayGuard:
    """Tracks (sender_id, nonce) pairs seen within the retention window.
    Retention window should be >= max TTL used anywhere in the system, so
    a replay can't sneak in after the entry ages out but before the
    envelope itself would have expired anyway."""
    def __init__(self, retention_seconds: float = 600):
        self._seen: dict[tuple[str, str], float] = {}
        self.retention_seconds = retention_seconds

    def check_and_record(self, sender_id: str, nonce: str, now: float | None = None) -> None:
        now = now if now is not None else time.time()
        self._gc(now)
        key = (sender_id, nonce)
        if key in self._seen:
            from wire_format import ReplayDetected
            raise ReplayDetected(f"nonce {nonce} from {sender_id} already seen -- replay rejected")
        self._seen[key] = now

    def _gc(self, now: float) -> None:
        cutoff = now - self.retention_seconds
        stale = [k for k, t in self._seen.items() if t < cutoff]
        for k in stale:
            del self._seen[k]
