# Status of the propagation + ranking modules (prototype, NOT validated)

Files: `synth_propagation.py`, `model_propagation.py`, `train_propagation.py`

- `synth_propagation.py` runs and produces sane cascades (~1k exposure events,
  ~30% propagation, 3-4 hop depth). In the `uniform` control every
  source-dependent term (w_s, w_r, w_i, w_social) is zeroed, so it is a true null.
- `train_propagation.py` runs end to end (full-batch, combined BCE + pairwise
  rank loss, source-ablation delta) but its real-vs-control check does NOT pass
  yet. 3-seed result: real mean delta = -0.044 (std 0.046), control mean
  delta = +0.045 (std 0.026), i.e. inverted. Almost all of the movement is in
  the rank-loss component, which is noisy: only a few hundred propagated events
  fall into (account, wave) groups of size >= 2, and early stopping on a
  validation loss that small selects arbitrary epochs.
- Likely next steps: score the two heads separately (report propagation-head
  delta on its own, which is positive in the real condition for 2 of 3 seeds),
  generate far more events per run, and judge the rank head with a rank
  correlation on held-out groups instead of the raw pairwise loss.

The earlier `train.py` / `synth_data.py` / `model.py` single-task pipeline is
the one with the documented real/control results (see README.md and paper.md).
