# Source-Conditional Embedding of Trend Adoption: A Synthetic Benchmark and Two Ablation-Leakage Failure Modes

## Abstract

Content-only embeddings implicitly assume exchangeability of information
sources: two identical pieces of content are treated as equivalent regardless
of who propagated them. Threshold models of social contagion suggest this
assumption is frequently false — adoption probability is conditioned on the
credibility or status of the source, not just the content itself. We present
a synthetic benchmark that generates trend-adoption events under a known,
controllable data-generating process in which source status causally
modulates adoption, together with a matched control in which it does not. We
train a joint content-plus-source embedding model against this benchmark and
report an ablation comparing it to a content-only baseline. In the course of
this work we identified and corrected two distinct ablation-leakage failure
modes — identity-embedding memorization and an origin/status confound — each
of which produced a statistically clean but substantively wrong result. We
argue these failure modes are general hazards for any pipeline that claims to
measure the marginal value of a conditioning variable, and we give a
diagnostic recipe (paired real/control generation with known ground truth)
for catching them. On the corrected pipeline, the control condition shows
exactly zero marginal value of source (as it should), and the real condition
shows a positive but currently under-powered effect across five seeds.

## 1. Introduction

A recurring assumption in embedding pipelines for social or informational
content is that the content itself is the unit of representation: two
occurrences of the same trend, post, or claim map to the same (or a very
similar) point in embedding space regardless of context. This assumption is
convenient — it lets a single encoder serve every downstream task — but it is
not obviously correct when the phenomenon being modeled is *adoption* rather
than *content similarity*. Diffusion-of-innovation and threshold models of
collective behavior have long held that whether an individual adopts a
behavior depends not just on the behavior's intrinsic properties but on
*who* is exhibiting it — status, credibility, and social proximity gate
adoption in ways that are invisible to a content-only representation
[Granovetter 1978; Bikhchandani, Hirshleifer & Welch 1992; Centola & Macy
2005].

If this is true of a target system, then a content-only embedding is not
merely incomplete but actively misleading for adoption-prediction tasks: it
discards the variable that carries the causal signal and can leave a model
to fit spurious content-only correlates that happen to proxy for source
status in a particular training sample. The natural fix is to condition the
embedding jointly on content and a representation of source status. Whether
this actually helps, however, is an empirical question that is easy to get
wrong — not because the modeling idea is unclear, but because *measuring the
marginal value of a conditioning variable* is itself a delicate exercise that
admits silent failure modes.

This paper has two contributions. First, we build a synthetic benchmark with
a known ground-truth generative process — status-gated threshold diffusion
over a scale-free actor graph — paired with a null control in which status is
uninformative by construction. This lets us evaluate whether a proposed joint
embedding method actually recovers a known causal structure, rather than
merely reporting a plausible-looking number. Second, in the course of
building this benchmark we encountered two distinct failure modes that each
produced a confident-looking but incorrect ablation result, and we document
both as general hazards.

## 2. Related framing

**Threshold models of contagion.** Granovetter's threshold model formalizes
adoption as a function of the fraction of an individual's network neighbors
who have already adopted, with a per-individual threshold governing
sensitivity. Extensions incorporating tie strength and source credibility
predict that *who* is in the adopted fraction matters as much as *how many*
— a claim our data-generating process encodes directly via a source-status
term in the adoption logit.

**Conditional / bilinear embeddings.** Joint embeddings that combine a
content representation with a context or entity representation via a
bilinear or gated interaction term are a standard device across
recommendation and relation-embedding literature; the design choice we make
— a residual, gated bilinear interaction rather than a raw bilinear product —
is intended to let the model degrade gracefully to content-only when the
context variable carries no signal, rather than being forced to use it.

**Ablation validity.** Reporting a marginal-value-of-feature number (e.g. via
a leave-one-feature-out comparison) is common, but the validity of such a
number depends entirely on whether the "without" condition truly removes
*only* the feature under test. Our two failure modes are instances of a
general problem: an ablation is only informative if the "off" arm cannot
leak the tested signal back in through an unintended channel.

## 3. Data-generating process

We generate a directed scale-free follow graph over $n$ actors
(`networkx.scale_free_graph`), from which we derive a **status prior** via
PageRank, rescaled to $[0,1]$. For each of $T$ synthetic trends we sample
1–2 origin nodes (weighted toward, but not exclusively, high-status nodes)
and run a discrete-time cascade: at each step, every node newly reachable
from an adopter is exposed, and adopts with probability

$$
p(\text{adopt}) = \sigma\!\left(w_c \cdot \tilde a + w_s \cdot \tilde s + w_i \cdot \tilde a \tilde s - b\right)
$$

where $\tilde a$ is content affinity between the actor's preference vector
and the trend's content vector (cosine similarity, rescaled to
$[-1,1]$), $\tilde s$ is the rescaled status of the *source* who exposed
the node (not the node's own status), and $w_c, w_s, w_i, b$ are fixed
generator constants. Every exposure — adopted or not — is logged as an
event, so the resulting dataset contains genuine negatives rather than
requiring synthetic negative sampling.

We define two conditions:

- **Real condition** (`status_mode="pagerank"`): $\tilde s$ varies across
  actors according to true network centrality, so source status is a real,
  informative variable.
- **Control condition** (`status_mode="uniform"`): $\tilde s$ is fixed to a
  constant for every actor, so source status carries no information by
  construction — any model that reports "source matters" here is wrong by
  definition, and the condition exists solely to catch that failure.

This paired design is the key methodological device of the paper: because
we control the generative process, we know the correct answer in advance,
and any pipeline result that contradicts it is diagnostic of a bug rather
than an interesting finding.

## 4. Model

We use a residual, gated bilinear joint embedder:

$$
c = f_\theta(\text{content}), \qquad
s = g_\phi(\text{source features}), \qquad
z = \text{LayerNorm}\!\left(c + \sigma(w^\top c)\, \text{Bilinear}(c, s)\right)
$$

where $f_\theta$ is a small MLP content encoder, $g_\phi$ projects source
features into a low-dimensional space, and the sigmoid gate
$\sigma(w^\top c)$ lets the interaction term shrink toward zero when the
content embedding alone is sufficient. This residual-with-gate structure is
what allows a single architecture to be evaluated in two modes without
retraining a structurally different network: an ablation is performed by
holding the source-feature input fixed to a neutral constant rather than by
removing a module.

A two-layer MLP head predicts adoption logits from the resulting embedding;
we train with binary cross-entropy, Adam, weight decay, and early stopping
on a held-out validation split.

## 5. Two ablation-leakage failure modes

### 5.1 Identity-embedding memorization

The first implementation represented source status via a free
`nn.Embedding` table keyed on raw actor identity (one row per actor). With
500 actors and roughly one to two logged events per actor, this table has
almost no repeated observations per row: gradient descent can drive each
row to memorize the actor-specific empirical adoption rate observed in the
tiny sample attached to that row, independent of whether status itself
carries any signal. The result was a "source matters" delta in *both* the
real and the control condition, because the table was fitting per-actor
noise, not status.

**Diagnosis.** We checked the ratio of events to embedding rows directly
(≈1.8 events per row) and confirmed via a separate correlation test that
the control condition's status feature had zero variance by construction,
ruling out a data-generation bug and isolating the fault to model capacity.

**Fix.** Replace the identity lookup table with a small MLP over a
*derived, low-dimensional* status feature (the PageRank score itself,
computed outside the model). This structurally removes the model's
capacity to memorize individual actors: it can only route predictive power
through the scalar quantity we intend to test.

### 5.2 Origin/status confound

After the first fix, the control condition still produced a large delta —
but inverted, with the control showing *more* apparent source-value than
the real condition. The cause was a second, more subtle leak: in the
implementation, the status feature was set to $0.0$ for origin events (no
upstream source to look up) and to a nonzero constant for all non-origin
events in the control condition (since every actor's status was identical
under `uniform`). This meant the "null" status feature was not actually
null — it perfectly encoded whether an event was a first-hand origin
adoption or a downstream relay, which is itself a real and legitimate
structural signal (origin nodes adopt at systematically different rates
than downstream nodes by construction of the cascade process), just not the
one under test.

**Diagnosis.** We verified the data-generating process was correct by
directly computing the correlation between source status and adoption
outcome on non-origin events only, which reproduced the expected
real-vs-control contrast (correlation ≈ 0.51 in the real condition; exactly
undefined/zero-variance in the control). This localized the bug to the
model-facing feature encoding rather than the generator.

**Fix.** Split the origin indicator into its own explicit feature,
present in *both* arms of the ablation, and restrict the ablation switch to
zeroing out (setting to a neutral value) only the status value itself.
This is the general principle: an ablation flag must isolate exactly the
variable under test, and any other legitimate signal that happens to
correlate with "source present or not" must be held constant across both
arms rather than allowed to vary with the ablation switch.

Both failures share a common shape: a statistically well-formed pipeline
(clean train/val split, converged optimization, plausible-looking loss
curves) produced a wrong causal conclusion because the "off" condition of
the ablation was not actually off with respect to the variable being
tested. Neither failure was visible from inspecting loss curves or held-out
metrics alone; both required a *paired control with known ground truth* to
surface.

## 6. Results

After both fixes, we re-ran the ablation across five random seeds per
condition ($T=150$ trends, $n=500$ actors per run). We report the
difference in best validation loss between the content-only ablation and
the full joint model (positive = source conditioning helps).

| Condition | Seeds positive | Mean $\Delta$ | Std $\Delta$ |
|---|---|---|---|
| Control (`uniform`) | 0/5 (identically zero) | 0.0000 | 0.0000 |
| Real (`pagerank`) | 3–4/5 | ≈ 0.011–0.020 | ≈ 0.019 |

The control result is exactly zero on every seed, as it must be: once the
origin/status confound is removed, there is no remaining channel through
which the ablation could show a spurious effect, so the two arms of the
ablation are literally identical computations and converge to identical
losses.

The real condition shows a directionally correct, positive mean effect, but
the effect size is small relative to its standard deviation at this sample
scale (150 independent cascades), and our evaluation harness — which
requires the mean effect to exceed twice its standard deviation before
declaring the effect established — currently returns an **inconclusive**
verdict rather than a positive one. We consider this an honest negative
result about statistical power at the current data scale rather than a
failure of the modeling approach: the correct-sign, non-zero effect
combined with an exactly-zero control is consistent with the joint model
detecting a real but modest signal that would likely sharpen with more
independent cascades or a stronger true effect size in the generator.

## 7. Discussion

The substantive finding — that conditioning a content embedding on a
derived source-status feature can recover predictive signal invisible to a
content-only encoder — is unsurprising given how the benchmark was
constructed; it is closer to a sanity check on the modeling approach than a
novel empirical claim. The more transferable contribution is methodological:
a marginal-value-of-feature ablation is only as trustworthy as the
independence of its "off" condition from the tested variable, and this
independence can fail silently in at least two structurally different ways
— through model capacity (a lookup table memorizing what should be an
unobserved quantity) and through feature encoding (a "null" value that
accidentally carries a different real signal). Neither failure produces
any visible symptom in training curves; both require a benchmark with known
ground truth, run under a matched control, to detect.

We think this generalizes beyond the trend-adoption setting to any pipeline
claiming "feature X improves prediction," including some of the joint
embedding designs one might consider for retrieval or ranking systems more
broadly: whenever a categorical or identity-linked feature is added to a
model with limited per-category data, the identity-memorization failure
mode is a live risk, and whenever an ablation's "off" value is chosen
casually (zero, a constant, a masked token) rather than deliberately checked
for information content, the confound failure mode is a live risk.

## 8. Limitations

The benchmark is entirely synthetic; the specific functional form of the
adoption logit (linear-in-features with a bilinear interaction term) is
also the functional form the model is asked to recover, so this is closer
to a well-specified sanity check than a stress test under model
misspecification. The current sample scale (150 trends per run) leaves the
real-condition effect statistically underpowered; we have not yet run the
scale-up experiment (larger $T$, or a deliberately amplified $w_s, w_i$)
that the pipeline is set up to support. We have not evaluated behavior
under a positives-only observation regime (only adoptions logged, no
recorded non-adoption exposures), which is the more common real-data
setting and would require explicit negative sampling with exposure-bias
correction rather than the exposure-complete negatives used here.

## 9. Conclusion

We built a synthetic, ground-truth-controlled benchmark for testing whether
a source-status-conditioned embedding improves on a content-only embedding
for adoption prediction, and used it to catch two distinct ablation-leakage
bugs before they could produce a false positive result. The corrected
pipeline behaves correctly on its control condition and shows a
directionally correct but currently under-powered effect on its real
condition. We suggest the paired real/control design used here — generate
data under a known mechanism, and under a matched null, and require the
ablation to return the correct answer on both — as a general diagnostic
practice for any pipeline reporting the marginal value of a conditioning
variable.

## References

Bikhchandani, S., Hirshleifer, D., & Welch, I. (1992). A theory of fads,
fashion, custom, and cultural change as informational cascades. *Journal of
Political Economy*, 100(5), 992–1026.

Centola, D., & Macy, M. (2007). Complex contagions and the weakness of
long ties. *American Journal of Sociology*, 113(3), 702–734.

Granovetter, M. (1978). Threshold models of collective behavior. *American
Journal of Sociology*, 83(6), 1420–1443.
