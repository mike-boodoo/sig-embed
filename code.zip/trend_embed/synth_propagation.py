"""
Unified model: a network of peer accounts, each of which (a) has its own
curation/ranking behavior over trends it's exposed to, and (b) propagates
trends to followers as a function of how it ranked them. An account's OWN
rank score for a trend drives whether it propagates to followers, and once a
follower is exposed, THEY produce a new rank score governed by their own
affinity plus a pull toward the source's rank (social proof), which then
drives the next hop. One coupled process.

Ground truth mechanism (known, so recovery can be checked):

  exposure -> propagate?  (classification)
    p(propagate) = sigmoid(
          w_a * affinity(follower, trend)
        + w_s * source_status
        + w_r * source_rank_weight
        + w_i * affinity * source_rank_weight
        - bias
    )

  if propagated -> own_rank_score = w_own_a * affinity + w_social * source_rank_weight + noise

Control condition (status_mode="uniform"): ALL source-dependent terms
(w_s, w_r, w_i, w_social) are zeroed, so source features carry no
information by construction. Only content affinity and the origin/non-origin
structure remain.
"""

import numpy as np
import networkx as nx
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class PropagationEvent:
    trend_id: str
    account_id: int
    source_account_id: int | None   # None = origin
    source_status: float            # 0.5 neutral if origin
    source_rank_weight: float       # sigmoid(source's own rank score); 0.0 if origin
    content_affinity: float
    is_origin: bool
    propagated: int                 # 1 = adopted/reposted, 0 = exposed but declined
    own_rank_score: float | None    # None if not propagated
    wave: int
    timestamp: datetime


def make_follow_graph(n_accounts: int, seed: int = 0) -> nx.DiGraph:
    g = nx.DiGraph(nx.scale_free_graph(n_accounts, alpha=0.3, beta=0.55, gamma=0.15, seed=seed))
    g.remove_edges_from(nx.selfloop_edges(g))
    return g


def make_status(g: nx.DiGraph, mode: str = "pagerank") -> dict[int, float]:
    if mode == "uniform":
        return {n: 0.5 for n in g.nodes}
    pr = nx.pagerank(g, alpha=0.85)
    vals = np.array(list(pr.values()))
    lo, hi = vals.min(), vals.max()
    return {n: float((v - lo) / (hi - lo + 1e-9)) for n, v in pr.items()}


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def generate_propagation_events(
    n_accounts: int = 400,
    n_trends: int = 100,
    status_mode: str = "pagerank",     # "pagerank" (real) or "uniform" (control)
    content_dim: int = 32,
    w_a: float = 2.5, w_s: float = 2.0, w_r: float = 2.5, w_i: float = 1.5, bias: float = 2.3,
    w_own_a: float = 2.0, w_social: float = 1.5, rank_noise: float = 0.4,
    max_hops: int = 6,
    seed: int = 0,
):
    """Returns (events, graph, status, trend_vecs)."""
    rng = np.random.default_rng(seed)
    if status_mode == "uniform":
        w_s = w_r = w_i = w_social = 0.0   # true null: no source-dependent mechanism at all

    g = make_follow_graph(n_accounts, seed=seed)
    status = make_status(g, mode=status_mode)
    accounts = list(g.nodes)

    trend_vecs = {f"trend_{i}": rng.normal(size=content_dim).astype(np.float32) for i in range(n_trends)}
    pref_vecs = {a: rng.normal(size=content_dim).astype(np.float32) for a in accounts}

    def affinity(acct, tvec):
        v = pref_vecs[acct]
        denom = np.linalg.norm(v) * np.linalg.norm(tvec) + 1e-9
        return float((np.dot(v, tvec) / denom + 1) / 2)

    events: list[PropagationEvent] = []
    t0 = datetime(2026, 1, 1)

    for trend_id, tvec in trend_vecs.items():
        weights = np.array([status[a] + 0.05 for a in accounts]); weights /= weights.sum()
        origins = rng.choice(accounts, size=min(2, len(accounts)), replace=False, p=weights)

        own_rank: dict = {}
        seen: set = set()
        for o in origins.tolist():
            aff = affinity(o, tvec)
            score = w_own_a * (aff - 0.5) * 2 + rng.normal(scale=rank_noise)
            own_rank[o] = score
            seen.add(o)
            events.append(PropagationEvent(
                trend_id=trend_id, account_id=o, source_account_id=None,
                source_status=0.5, source_rank_weight=0.0, content_affinity=aff,
                is_origin=True, propagated=1, own_rank_score=score, wave=0, timestamp=t0,
            ))

        frontier = set(origins.tolist())
        t = t0
        for wave in range(1, max_hops + 1):
            next_frontier = set()
            for node in frontier:
                for nbr in g.successors(node):
                    if nbr in seen:
                        continue
                    seen.add(nbr)
                    src_status = status[node]
                    src_rank_weight = float(sigmoid(own_rank[node]))
                    aff = affinity(nbr, tvec)

                    logit = (
                        w_a * (aff - 0.5) * 2
                        + w_s * (src_status - 0.5) * 2
                        + w_r * (src_rank_weight - 0.5) * 2
                        + w_i * (aff - 0.5) * (src_rank_weight - 0.5) * 4
                        - bias
                    )
                    did = rng.random() < sigmoid(logit)

                    own_score = None
                    if did:
                        own_score = (
                            w_own_a * (aff - 0.5) * 2
                            + w_social * (src_rank_weight - 0.5) * 2
                            + rng.normal(scale=rank_noise)
                        )
                        own_rank[nbr] = own_score
                        next_frontier.add(nbr)

                    events.append(PropagationEvent(
                        trend_id=trend_id, account_id=nbr, source_account_id=node,
                        source_status=src_status, source_rank_weight=src_rank_weight,
                        content_affinity=aff, is_origin=False, propagated=int(did),
                        own_rank_score=own_score, wave=wave, timestamp=t,
                    ))
            frontier = next_frontier
            t += timedelta(hours=1)
            if not frontier:
                break

    return events, g, status, trend_vecs


if __name__ == "__main__":
    events, g, status, _ = generate_propagation_events()
    n_prop = sum(e.propagated for e in events)
    print(f"{len(events)} exposure events, {n_prop} propagations ({n_prop/len(events):.1%})")
    print(f"graph: {g.number_of_nodes()} nodes, {g.number_of_edges()} edges")
    print(f"waves present: {sorted(set(e.wave for e in events))}")
