"""
Trains the shared PropagationEmbedder against two coupled objectives:

  1. propagation classification: did the follower repost, given exposure? (BCE)
  2. intra-account rank ordering: among trends an account DID adopt in the
     same wave, does the score order match the ground-truth rank order?
     (pairwise loss, grouped by (account_id, wave))

Training is FULL-BATCH: groups are (account, wave) and a random minibatch
would almost never contain two events from the same group, silently turning
the rank loss into zero. With ~1k events full-batch is cheap and keeps the
group structure intact.

use_source=False ablates source_status -> 0.5 and source_rank_weight -> 0,
while keeping is_origin (a legitimate structural fact, not the hypothesis
under test).

Usage:  python3 train_propagation.py          # multi-seed real vs control
        python3 train_propagation.py --quick  # one seed each
"""

import sys
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn

from synth_propagation import generate_propagation_events
from model_propagation import PropagationEmbedder, PropagationHead, RankScoreHead, pairwise_rank_loss


def to_tensors(events, trend_vecs):
    return {
        "content": torch.tensor(np.stack([trend_vecs[e.trend_id] for e in events]), dtype=torch.float32),
        "status": torch.tensor([[e.source_status] for e in events], dtype=torch.float32),
        "rank_w": torch.tensor([[e.source_rank_weight] for e in events], dtype=torch.float32),
        "is_origin": torch.tensor([[float(e.is_origin)] for e in events], dtype=torch.float32),
        "propagated": torch.tensor([float(e.propagated) for e in events], dtype=torch.float32),
        "rank_target": torch.tensor([e.own_rank_score if e.own_rank_score is not None else 0.0 for e in events],
                                    dtype=torch.float32),
        "group": [(e.account_id, e.wave) for e in events],
    }


def subset(t, idx):
    idx_t = torch.tensor(idx)
    out = {k: v[idx_t] for k, v in t.items() if k != "group"}
    out["group"] = [t["group"][i] for i in idx]
    return out


def rank_loss(scores, targets, propagated, groups):
    by_group = defaultdict(list)
    for i, (g, p) in enumerate(zip(groups, propagated.tolist())):
        if p > 0.5:
            by_group[g].append(i)
    losses = [pairwise_rank_loss(scores[torch.tensor(ix)], targets[torch.tensor(ix)])
              for ix in by_group.values() if len(ix) >= 2]
    return torch.stack(losses).mean() if losses else scores.sum() * 0.0


def evaluate(embedder, prop_head, rank_head, t, use_source, bce, rank_w):
    status = t["status"] if use_source else torch.full_like(t["status"], 0.5)
    rw = t["rank_w"] if use_source else torch.zeros_like(t["rank_w"])
    emb, _ = embedder(t["content"], status, rw, t["is_origin"])
    l_prop = bce(prop_head(emb), t["propagated"])
    l_rank = rank_loss(rank_head(emb), t["rank_target"], t["propagated"], t["group"])
    return l_prop + rank_w * l_rank, l_prop, l_rank


def train_one_model(events, trend_vecs, use_source, epochs=200, lr=3e-3, seed=0,
                    weight_decay=1e-3, patience=20, rank_loss_weight=1.0, verbose=False):
    torch.manual_seed(seed)
    t = to_tensors(events, trend_vecs)
    n = len(events)
    idx = np.random.default_rng(seed).permutation(n)
    split = int(0.8 * n)
    train_t, val_t = subset(t, idx[:split].tolist()), subset(t, idx[split:].tolist())

    embedder, prop_head, rank_head = PropagationEmbedder(), PropagationHead(), RankScoreHead()
    params = list(embedder.parameters()) + list(prop_head.parameters()) + list(rank_head.parameters())
    opt = torch.optim.Adam(params, lr=lr, weight_decay=weight_decay)
    bce = nn.BCEWithLogitsLoss()

    best_val, since = float("inf"), 0
    for epoch in range(epochs):
        embedder.train(); prop_head.train(); rank_head.train()
        loss, _, _ = evaluate(embedder, prop_head, rank_head, train_t, use_source, bce, rank_loss_weight)
        opt.zero_grad(); loss.backward(); opt.step()

        embedder.eval(); prop_head.eval(); rank_head.eval()
        with torch.no_grad():
            val, v_prop, v_rank = evaluate(embedder, prop_head, rank_head, val_t, use_source, bce, rank_loss_weight)
        if val.item() < best_val - 1e-4:
            best_val, since = val.item(), 0
            best_parts = (v_prop.item(), v_rank.item())
        else:
            since += 1
        if verbose and epoch % 25 == 0:
            print(f"  epoch {epoch:3d} train={loss.item():.4f} val={val.item():.4f} best={best_val:.4f}")
        if since >= patience:
            break
    return best_val, best_parts


def run_multi_seed(status_mode, label, seeds=(1, 2, 3), n_trends=120):
    print(f"\n=== {label} (status_mode={status_mode}, seeds={list(seeds)}) ===")
    deltas, prop_deltas, rank_deltas = [], [], []
    for seed in seeds:
        events, g, status, trend_vecs = generate_propagation_events(
            status_mode=status_mode, n_trends=n_trends, seed=seed)
        v_with, p_with = train_one_model(events, trend_vecs, use_source=True, seed=seed)
        v_without, p_without = train_one_model(events, trend_vecs, use_source=False, seed=seed)
        deltas.append(v_without - v_with)
        prop_deltas.append(p_without[0] - p_with[0])
        rank_deltas.append(p_without[1] - p_with[1])
        print(f"  seed {seed}: {len(events)} events  total_delta={deltas[-1]:+.4f}  "
              f"prop_delta={prop_deltas[-1]:+.4f}  rank_delta={rank_deltas[-1]:+.4f}")
    d = np.array(deltas)
    print(f"  mean total delta={d.mean():+.4f}  std={d.std():.4f}  (positive = source helps)")
    return d


if __name__ == "__main__":
    seeds = (1,) if "--quick" in sys.argv else (1, 2, 3)
    real = run_multi_seed("pagerank", "real status-gated propagation", seeds=seeds)
    control = run_multi_seed("uniform", "control (no source-dependent mechanism)", seeds=seeds)
    print("\n=== summary ===")
    print(f"real:    mean_delta={real.mean():+.4f}  std={real.std():.4f}")
    print(f"control: mean_delta={control.mean():+.4f}  std={control.std():.4f}")
    print("expect: real clearly > control; control ~ 0")
