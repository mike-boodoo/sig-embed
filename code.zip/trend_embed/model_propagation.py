import torch
import torch.nn as nn


class ContentEncoder(nn.Module):
    def __init__(self, in_dim=32, out_dim=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_dim, out_dim), nn.ReLU(), nn.Linear(out_dim, out_dim))

    def forward(self, x):
        return self.net(x)


class PropagationEmbedder(nn.Module):
    """content ⊕ [source_status, source_rank_weight, is_origin] via a residual
    gated bilinear interaction. Source features are DERIVED SCALARS, not a
    per-account identity lookup (avoids the memorization failure mode found in
    the first trend_embed pipeline). is_origin is its own explicit feature so
    it can't masquerade as a status/rank value (the second failure mode)."""
    def __init__(self, content_in_dim=32, content_dim=64, source_hidden=16):
        super().__init__()
        self.content_encoder = ContentEncoder(content_in_dim, content_dim)
        self.source_proj = nn.Sequential(
            nn.Linear(3, source_hidden), nn.ReLU(), nn.Linear(source_hidden, source_hidden)
        )
        self.interaction = nn.Bilinear(content_dim, source_hidden, content_dim)
        self.gate = nn.Linear(content_dim, 1)
        self.out_norm = nn.LayerNorm(content_dim)

    def forward(self, content_vecs, source_status, source_rank_weight, is_origin):
        c = self.content_encoder(content_vecs)
        s = self.source_proj(torch.cat([source_status, source_rank_weight, is_origin], dim=-1))
        gate = torch.sigmoid(self.gate(c))
        return self.out_norm(c + gate * self.interaction(c, s)), c


class PropagationHead(nn.Module):
    """Predicts P(propagate | exposed) logits."""
    def __init__(self, embed_dim=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(embed_dim, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, emb):
        return self.net(emb).squeeze(-1)


class RankScoreHead(nn.Module):
    """Bare relevance score; only pairwise order within a group matters."""
    def __init__(self, embed_dim=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(embed_dim, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, emb):
        return self.net(emb).squeeze(-1)


def pairwise_rank_loss(scores: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    """RankNet-style: push score_i > score_j whenever target_i > target_j."""
    diff_scores = scores.unsqueeze(1) - scores.unsqueeze(0)
    diff_targets = targets.unsqueeze(1) - targets.unsqueeze(0)
    mask = diff_targets != 0
    if mask.sum() == 0:
        return scores.sum() * 0.0
    target_sign = (diff_targets > 0).float()
    return nn.functional.binary_cross_entropy_with_logits(diff_scores[mask], target_sign[mask])
