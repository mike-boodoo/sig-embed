import torch
import torch.nn as nn


class ContentEncoder(nn.Module):
    """Stand-in for a real sentence encoder. Trend content here is already a
    vector (see synth_data); a real pipeline would swap this for a frozen
    sentence-transformer + a small projection head."""
    def __init__(self, in_dim=32, out_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, out_dim), nn.ReLU(), nn.Linear(out_dim, out_dim)
        )

    def forward(self, x):
        return self.net(x)


class JointTrendEmbedder(nn.Module):
    """content ⊕ source-status, combined via a *residual* bilinear interaction.

    IMPORTANT — do not give this a free per-actor embedding table unless you
    have enough events per actor to fill it (rule of thumb: >>10 events per
    row). With sparse data, a per-actor nn.Embedding degenerates into a
    lookup table that memorizes per-actor noise and will show a spurious
    "source matters" signal even when status is uninformative (this bit us
    in the first version of this pipeline — see train.py docstring).

    Correct structure for sparse data: derive a low-dimensional STATUS
    FEATURE per actor from graph structure (e.g. pagerank) outside the
    model, and embed *that scalar/small-vector*, not the actor's raw
    identity. This caps the model's capacity to memorize individual actors
    and forces it to route through the quantity we actually hypothesize
    matters.
    """
    def __init__(self, content_in_dim=32, content_dim=64, source_hidden=16):
        super().__init__()
        self.content_encoder = ContentEncoder(content_in_dim, content_dim)
        # Input is [status_feat, is_origin] -- kept as SEPARATE features so
        # "no source" can't masquerade as a particular status value (see
        # train.py AdoptionDataset docstring for the bug this caused).
        self.source_proj = nn.Sequential(
            nn.Linear(2, source_hidden), nn.ReLU(),
            nn.Linear(source_hidden, source_hidden),
        )
        self.interaction = nn.Bilinear(content_dim, source_hidden, content_dim)
        self.gate = nn.Linear(content_dim, 1)
        self.out_norm = nn.LayerNorm(content_dim)

    def forward(self, content_vecs, status_feats, is_origin):
        """status_feats: (B,1) status value of source (0.5 neutral default for
        origin events). is_origin: (B,1) explicit 0/1 flag."""
        c = self.content_encoder(content_vecs)
        src_input = torch.cat([status_feats, is_origin], dim=-1)
        s = self.source_proj(src_input)
        interact = self.interaction(c, s)
        gate = torch.sigmoid(self.gate(c))
        joint = c + gate * interact
        return self.out_norm(joint), c


class AdoptionHead(nn.Module):
    """Predicts P(adopt) from an embedding. Used on top of either the
    joint embedding or the content-only embedding for the ablation compare."""
    def __init__(self, embed_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(embed_dim, 32), nn.ReLU(), nn.Linear(32, 1)
        )

    def forward(self, emb):
        return self.net(emb).squeeze(-1)  # logits
