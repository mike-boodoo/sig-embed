# Source-conditional trend embedding — synthetic pipeline

Tests whether a content embedding jointly conditioned on source status
outperforms a content-only embedding for predicting trend adoption, using
synthetic data where the ground-truth mechanism is known.

## Files

- `synth_data.py` — generates adoption events over a scale-free actor graph.
  Two modes: `pagerank` (source status = real pagerank score, so it should
  carry signal) and `uniform` (source status is constant, a **control** —
  source should carry *no* signal here).
- `model.py` — `JointTrendEmbedder`: content embedding + source-status
  embedding combined via a residual bilinear interaction, gated so the
  model can fall back to content-only when source doesn't help.
- `train.py` — training loop with early stopping, plus the ablation:
  train with real `status_feat` vs. with `status_feat` fixed to a neutral
  value, and compare val loss. Run with `python3 train.py --quick` for a
  single fast sanity-check seed, or `python3 train.py` for the multi-seed
  eval that the actual claim should be judged on.

## Bug found and fixed during development

First version used `nn.Embedding(num_actors, dim)` keyed on raw actor
identity for the "source" side. With ~500 actors and only ~1-2 events per
actor, that's a lookup table with almost no repeated observations per row —
it memorizes per-actor noise rather than learning anything about status,
and both the real and control conditions showed a "source matters" signal
for the wrong reason (memorization capacity, not status).

Fix: replaced the identity embedding with a small MLP over a *derived*
scalar feature (pagerank score), so the model can't memorize individual
actors — it can only route through the quantity we're actually testing.

Second bug, same root cause in different clothes: after that fix, the
"uniform" control still showed a large *inverted* delta (control > real).
Cause: `status_feat` was 0.0 for origin events and a nonzero constant for
non-origin events in the control, which accidentally encoded a real,
legitimate signal (was this trend seen firsthand vs. relayed) as if it
were the null status signal. Fixed by splitting `is_origin` out as its own
feature, present in both the "with source" and "without source" ablation
arms, so only the status *value* itself is what gets ablated.

Both fixes follow the same lesson: an ablation is only clean if the
"off" condition can't leak information through a side channel you didn't
intend to control.

## Current result

Control condition: delta is exactly 0.0000 across all seeds — correct,
since ablating status_feat when it was already constant changes nothing.

Real condition: mean delta positive (~0.01-0.02) across 5 seeds, 3-4/5
individually positive, but std is large relative to mean at this data
scale (150 trends, ~500 actors) — the harness currently reports this as
`INCONCLUSIVE` rather than `PASS`. That's the honest read: the mechanism
is directionally correct but under-powered for a confident claim at this
n. To get a clean PASS, scale `n_trends` up (more independent cascades =
tighter estimate) or increase `w_status`/`w_interact` in `generate_events`
to simulate a stronger true effect and confirm the harness detects it
when it's really there.

## Next steps if you want to push this further

1. Run `n_trends=500+` to see if the real-condition delta separates from
   noise with more independent cascades.
2. Swap `ContentEncoder` for a frozen sentence-transformer + projection
   head once you have real text content instead of random vectors.
3. If you get real timestamped data, the `AdoptionEvent`/`generate_events`
   interface is the contract to match — replace the generator, keep the
   model/train code as-is.
