"""
Synthetic generator for source-conditional trend adoption.

Ground truth model (known, so we can check if learned embeddings recover it):

  P(actor adopts trend | seen from source) = sigmoid(
        w_content * content_affinity(actor, trend)
      + w_status   * true_status[source]
      + w_interact * content_affinity(actor, trend) * true_status[source]
      - bias
  )

true_status is generated independently of content, so any model that only
sees content (and not source) is structurally incapable of matching this
process above chance set by content_affinity alone. That gap is the thing
we're testing for.

We also inject a *null* condition (uniform_status) as a control: with
uniform_status, source carries no information, and a well-built pipeline
should report marginal_source_value near zero on that data.
"""

import numpy as np
import networkx as nx
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import random

RNG = np.random.default_rng(0)


@dataclass
class AdoptionEvent:
    trend_id: str
    actor_id: str
    source_actor_id: str | None
    timestamp: datetime
    content: str
    content_vec: np.ndarray
    adopted: int  # 1 = adopted, 0 = exposed but did not adopt (negative sample)


def make_actor_graph(n_actors: int, avg_out_degree: int = 8, seed: int = 0) -> nx.DiGraph:
    """Scale-free-ish follow graph so status has real variance (a few hubs)."""
    g = nx.scale_free_graph(n_actors, alpha=0.3, beta=0.55, gamma=0.15, seed=seed)
    g = nx.DiGraph(g)  # collapse multi-edges
    g.remove_edges_from(nx.selfloop_edges(g))
    return g


def make_true_status(g: nx.DiGraph, mode: str = "pagerank") -> dict[str, float]:
    if mode == "uniform":
        return {n: 0.5 for n in g.nodes}
    pr = nx.pagerank(g, alpha=0.85)
    vals = np.array(list(pr.values()))
    # rescale to [0,1] so it's on a comparable footing to content_affinity
    lo, hi = vals.min(), vals.max()
    return {n: float((v - lo) / (hi - lo + 1e-9)) for n, v in pr.items()}


def make_trend_content_vecs(n_trends: int, dim: int = 32) -> dict[str, np.ndarray]:
    return {f"trend_{i}": RNG.normal(size=dim).astype(np.float32) for i in range(n_trends)}


def make_actor_pref_vecs(n_actors: int, dim: int = 32) -> dict[int, np.ndarray]:
    return {a: RNG.normal(size=dim).astype(np.float32) for a in range(n_actors)}


def content_affinity(actor_vec: np.ndarray, trend_vec: np.ndarray) -> float:
    # cosine similarity, squashed to [0,1]
    num = np.dot(actor_vec, trend_vec)
    denom = (np.linalg.norm(actor_vec) * np.linalg.norm(trend_vec) + 1e-9)
    return float((num / denom + 1) / 2)


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + np.exp(-x))


def generate_events(
    n_actors: int = 500,
    n_trends: int = 40,
    status_mode: str = "pagerank",   # "pagerank" (real signal) or "uniform" (control)
    w_content: float = 3.0,
    w_status: float = 2.5,
    w_interact: float = 2.0,
    bias: float = 2.5,
    seed: int = 0,
) -> tuple[list[AdoptionEvent], nx.DiGraph, dict, dict, dict]:
    random.seed(seed)
    g = make_actor_graph(n_actors, seed=seed)
    true_status = make_true_status(g, mode=status_mode)
    trend_vecs = make_trend_content_vecs(n_trends)
    actor_vecs = make_actor_pref_vecs(n_actors)

    events: list[AdoptionEvent] = []
    t0 = datetime(2026, 1, 1)

    for trend_id, tvec in trend_vecs.items():
        # pick 1-3 origin nodes weighted by status (trends start from influential-ish people
        # more often, but not exclusively -- keeps it realistic, not tautological)
        nodes = list(g.nodes)
        weights = np.array([true_status[n] + 0.05 for n in nodes])
        weights /= weights.sum()
        origins = RNG.choice(nodes, size=min(2, len(nodes)), replace=False, p=weights)

        frontier = set(int(o) for o in origins)
        adopted = set()
        t = t0
        depth = 0
        source_of = {int(o): None for o in origins}

        while frontier and depth < 6:
            next_frontier = set()
            for node in frontier:
                if node in adopted:
                    continue
                src = source_of.get(node)
                src_status = true_status[node] if src is None else true_status[src]
                aff = content_affinity(actor_vecs[node], tvec)

                if src is None:
                    p_adopt = sigmoid(w_content * (aff - 0.5) * 2 - bias + 3)  # origins adopt readily
                else:
                    logit = (
                        w_content * (aff - 0.5) * 2
                        + w_status * (src_status - 0.5) * 2
                        + w_interact * (aff - 0.5) * (src_status - 0.5) * 4
                        - bias
                    )
                    p_adopt = sigmoid(logit)

                did_adopt = RNG.random() < p_adopt
                events.append(AdoptionEvent(
                    trend_id=trend_id,
                    actor_id=str(node),
                    source_actor_id=None if src is None else str(src),
                    timestamp=t,
                    content=trend_id,
                    content_vec=tvec,
                    adopted=int(did_adopt),
                ))

                if did_adopt:
                    adopted.add(node)
                    for nbr in g.successors(node):
                        if nbr not in adopted and nbr not in source_of:
                            source_of[nbr] = node
                            next_frontier.add(nbr)

            frontier = next_frontier
            t += timedelta(hours=1)
            depth += 1

    return events, g, true_status, trend_vecs, actor_vecs


if __name__ == "__main__":
    events, g, status, trend_vecs, actor_vecs = generate_events()
    n_pos = sum(e.adopted for e in events)
    print(f"generated {len(events)} events, {n_pos} adoptions ({n_pos/len(events):.1%})")
    print(f"graph: {g.number_of_nodes()} nodes, {g.number_of_edges()} edges")
    print(f"status range: {min(status.values()):.3f} - {max(status.values()):.3f}")
