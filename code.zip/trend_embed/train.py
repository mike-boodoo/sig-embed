"""
Training loop for the joint content+source embedder.

Negative sampling note: synth_data already emits both adopted=1 and
adopted=0 events (every exposure is logged, not just adoptions), so this
is NOT the classic "only positives observed" retrieval setup -- we don't
need to sample fake negatives, we have real ones (exposed-but-declined).
That's the correct setup for adoption modeling; if you only had positive
adoption logs you'd need to sample non-adopters as negatives and correct
for exposure bias, which is a different (harder) problem -- flag if your
real data ends up being positives-only.
"""

import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import Dataset, DataLoader

from synth_data import generate_events, AdoptionEvent
from model import JointTrendEmbedder, AdoptionHead


class AdoptionDataset(Dataset):
    """status_feat is a derived scalar (e.g. pagerank), NOT an actor-id
    lookup -- see model.py docstring for why a raw identity embedding
    overfits on sparse event data."""
    def __init__(self, events: list[AdoptionEvent], status_by_actor: dict):
        self.events = events
        self.status_by_actor = status_by_actor

    def __len__(self):
        return len(self.events)

    def __getitem__(self, i):
        e = self.events[i]
        is_origin = e.source_actor_id is None
        # status_feat and is_origin are SEPARATE features. Previously status_feat
        # alone was 0.0 for origins and a nonzero constant for non-origins in the
        # "uniform" control -- that accidentally leaked a perfect origin/non-origin
        # flag through what was supposed to be a null status signal, inverting the
        # ablation result. Now is_origin carries that (real, legitimate) structural
        # signal explicitly, and status_feat carries ONLY the status value, with a
        # neutral 0.5 default when there's no source to look up.
        status_feat = (
            0.5 if is_origin
            else self.status_by_actor[e.source_actor_id]
        )
        return {
            "content_vec": torch.tensor(e.content_vec, dtype=torch.float32),
            "status_feat": torch.tensor([status_feat], dtype=torch.float32),
            "is_origin": torch.tensor([float(is_origin)], dtype=torch.float32),
            "label": torch.tensor(e.adopted, dtype=torch.float32),
        }


def build_dataset(events, status: dict):
    status_by_actor = {str(k): v for k, v in status.items()}
    ds = AdoptionDataset(events, status_by_actor)
    return ds


def train_one_model(events, status, use_source: bool, epochs=40, lr=1e-3, seed=0,
                     weight_decay=1e-3, patience=6):
    """use_source=False trains the content-only ablation by setting status_feat
    to the neutral 0.5 value for every event (matching what origin events see),
    while leaving is_origin untouched. is_origin is kept in BOTH conditions
    because it's a legitimate structural fact (was this trend seen firsthand
    vs relayed), not the specific hypothesis under test (does source STATUS
    matter). Ablating only status_feat isolates that hypothesis cleanly --
    see model.py / this file's Dataset docstring for the bug this fixes.

    Early stopping + weight decay: with limited events, an unregularized
    net still overfits. We report the BEST val_loss seen, not final-epoch,
    so the joint-vs-content delta reflects generalization.
    """
    torch.manual_seed(seed)
    ds = build_dataset(events, status)

    n = len(ds)
    idx = np.random.default_rng(seed).permutation(n)
    split = int(0.8 * n)
    train_idx, val_idx = idx[:split], idx[split:]
    train_loader = DataLoader(ds, batch_size=64, sampler=train_idx.tolist())
    val_loader = DataLoader(ds, batch_size=64, sampler=val_idx.tolist())

    embedder = JointTrendEmbedder()
    head = AdoptionHead(embed_dim=64)
    opt = torch.optim.Adam(
        list(embedder.parameters()) + list(head.parameters()), lr=lr, weight_decay=weight_decay
    )
    loss_fn = nn.BCEWithLogitsLoss()

    best_val_loss = float("inf")
    epochs_since_improve = 0

    for epoch in range(epochs):
        embedder.train(); head.train()
        total_loss = 0.0
        for batch in train_loader:
            status_feat = batch["status_feat"] if use_source else torch.full_like(batch["status_feat"], 0.5)
            joint_emb, content_emb = embedder(batch["content_vec"], status_feat, batch["is_origin"])
            logits = head(joint_emb)
            loss = loss_fn(logits, batch["label"])
            opt.zero_grad(); loss.backward(); opt.step()
            total_loss += loss.item() * len(batch["label"])
        train_loss = total_loss / len(train_idx)

        embedder.eval(); head.eval()
        with torch.no_grad():
            val_loss_total, val_n = 0.0, 0
            for batch in val_loader:
                status_feat = batch["status_feat"] if use_source else torch.full_like(batch["status_feat"], 0.5)
                joint_emb, _ = embedder(batch["content_vec"], status_feat, batch["is_origin"])
                logits = head(joint_emb)
                l = loss_fn(logits, batch["label"])
                val_loss_total += l.item() * len(batch["label"])
                val_n += len(batch["label"])
            val_loss = val_loss_total / val_n

        if val_loss < best_val_loss - 1e-4:
            best_val_loss = val_loss
            epochs_since_improve = 0
        else:
            epochs_since_improve += 1

        if epoch % 5 == 0 or epoch == epochs - 1:
            print(f"  epoch {epoch:2d}  train_loss={train_loss:.4f}  val_loss={val_loss:.4f}  best={best_val_loss:.4f}")

        if epochs_since_improve >= patience:
            print(f"  early stop at epoch {epoch} (no improvement for {patience} epochs)")
            break

    return embedder, head, best_val_loss


def run_condition(status_mode: str, label: str, n_trends: int = 150):
    print(f"\n=== condition: {label} (status_mode={status_mode}) ===")
    events, g, status, trend_vecs, actor_vecs = generate_events(
        status_mode=status_mode, seed=1, n_trends=n_trends
    )
    print(f"  {len(events)} events across {n_trends} trends, {g.number_of_nodes()} actors")

    print("training WITH source conditioning:")
    _, _, val_loss_with = train_one_model(events, status, use_source=True, seed=1)

    print("training WITHOUT source conditioning (content-only ablation):")
    _, _, val_loss_without = train_one_model(events, status, use_source=False, seed=1)

    delta = val_loss_without - val_loss_with
    print(f"  val_loss content-only = {val_loss_without:.4f}")
    print(f"  val_loss joint        = {val_loss_with:.4f}")
    print(f"  delta (marginal value of source) = {delta:.4f}  "
          f"{'<-- source matters' if delta > 0.01 else '<-- ~no source signal (expected on control)'}")
    return delta


def run_multi_seed(status_mode: str, label: str, seeds=(1, 2, 3, 4, 5), n_trends=150):
    """Single-seed deltas are noisy at this data scale (see README) -- report
    mean/std across seeds so a positive result isn't a lucky draw."""
    print(f"\n=== multi-seed: {label} (status_mode={status_mode}, seeds={list(seeds)}) ===")
    deltas = []
    for seed in seeds:
        events, g, status, tv, av = generate_events(status_mode=status_mode, seed=seed, n_trends=n_trends)
        _, _, vl_with = train_one_model(events, status, use_source=True, seed=seed)
        _, _, vl_without = train_one_model(events, status, use_source=False, seed=seed)
        deltas.append(vl_without - vl_with)
    deltas = np.array(deltas)
    print(f"  deltas: {[round(d,4) for d in deltas]}")
    print(f"  mean={deltas.mean():.4f}  std={deltas.std():.4f}")
    return deltas


if __name__ == "__main__":
    import sys
    quick = "--quick" in sys.argv

    if quick:
        # Single seed, verbose -- for sanity-checking the pipeline runs end to end.
        delta_real = run_condition("pagerank", "real status-gated diffusion")
        delta_control = run_condition("uniform", "control (no true source signal)")
        print("\n=== summary ===")
        print(f"real condition delta:    {delta_real:.4f}  (expect clearly > 0)")
        print(f"control condition delta: {delta_control:.4f}  (expect ~0)")
    else:
        # Multi-seed -- the actual claim ("source status carries predictive
        # signal beyond content") should be judged on this, not a single run.
        real_deltas = run_multi_seed("pagerank", "real status-gated diffusion")
        control_deltas = run_multi_seed("uniform", "control (no true source signal)")

        print("\n=== final summary ===")
        print(f"real:    mean_delta={real_deltas.mean():.4f}  std={real_deltas.std():.4f}  "
              f"(n_positive={sum(real_deltas > 0)}/{len(real_deltas)})")
        print(f"control: mean_delta={control_deltas.mean():.4f}  std={control_deltas.std():.4f}")
        verdict = "PASS" if real_deltas.mean() > 2 * real_deltas.std() and abs(control_deltas.mean()) < 1e-3 else "INCONCLUSIVE"
        print(f"verdict: {verdict}")
